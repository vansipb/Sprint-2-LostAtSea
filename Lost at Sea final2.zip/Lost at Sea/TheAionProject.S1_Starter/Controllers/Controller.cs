﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LostAtSea
{
    /// <summary>
    /// controller for the MVC pattern in the application
    /// </summary>
    public class Controller
    {
        #region FIELDS

        private ConsoleView _gameConsoleView;
        private Survivor _gameTraveler;
        private Universe _gameUniverse;
        private IslandLocation _currentLocation;
        private bool _playingGame;

        #endregion

        #region PROPERTIES


        #endregion

        #region CONSTRUCTORS

        public Controller()
        {
            //
            // setup all of the objects in the game
            //
            InitializeGame();

            //
            // begins running the application UI
            //
            ManageGameLoop();
        }

        #endregion

        #region METHODS

        /// <summary>
        /// initialize the major game objects
        /// </summary>
        private void InitializeGame()
        {
            _gameTraveler = new Survivor();
            _gameUniverse = new Universe();
            _gameConsoleView = new ConsoleView(_gameTraveler, _gameUniverse);
            _playingGame = true;

            _gameTraveler.Inventory.Add(_gameUniverse.GetGameObjectById(8) as TravelerObject);

            Console.CursorVisible = false;
        }

        /// <summary>
        /// method to manage the application setup and game loop
        /// </summary>
        private void ManageGameLoop()
        {
            SurvivorAction travelerActionChoice = SurvivorAction.None;

            //
            // display splash screen
            //
            _playingGame = _gameConsoleView.DisplaySpashScreen();

            //
            // player chooses to quit
            //
            if (!_playingGame)
            {
                Environment.Exit(1);
            }

            //
            // display introductory message
            //
            _gameConsoleView.DisplayGamePlayScreen("Mission Intro", Text.MissionIntro(), ActionMenu.MissionIntro, "");
            _gameConsoleView.GetContinueKey();

            //
            // initialize the mission traveler
            // 
            InitializeMission();

            //
            // prepare game play screen
            //
            _currentLocation = _gameUniverse.GetIslandLocationById(_gameTraveler.lastname);
            _gameConsoleView.DisplayGamePlayScreen("Current Location", Text.CurrentLocationInfo(_currentLocation), ActionMenu.MainMenu, "");

            //
            // game loop
            //
            while (_playingGame)
            {
                //
                // process all flags, events, and stats
                //
                UpdateGameStatus();

                travelerActionChoice = _gameConsoleView.GetActionMenuChoice(ActionMenu.MainMenu);

                while (_playingGame)
                {
                    //
                    // process all flags, events, and stats
                    //
                    UpdateGameStatus();

                    //
                    // get next game action from player
                    //
                    if (ActionMenu.currentMenu == ActionMenu.CurrentMenu.MainMenu)
                    {
                        travelerActionChoice = _gameConsoleView.GetActionMenuChoice(ActionMenu.MainMenu);
                    }
                    else if (ActionMenu.currentMenu == ActionMenu.CurrentMenu.SecondaryMenu)
                    {
                        travelerActionChoice = _gameConsoleView.GetActionMenuChoice(ActionMenu.SecondaryMenu);
                    }

                    //
                    // choose an action based on the user's menu choice
                    //
                    switch (travelerActionChoice)
                    {
                        case SurvivorAction.None:
                            break;

                        case SurvivorAction.SurvivorInfo:
                            _gameConsoleView.DisplayTravelerInfo();
                            break;

                        case SurvivorAction.LookAround:
                            _gameConsoleView.DisplayLookAround();
                            break;

                        case SurvivorAction.Exit:
                            _playingGame = false;
                            break;

                        case SurvivorAction.ListSurvivorObjects:
                            _gameConsoleView.DisplayListOfAllGameObjects();
                            break;

                        case SurvivorAction.LookAt:
                            LookAtAction();
                            break;

                        case SurvivorAction.PickUp:
                            PickUpAction();
                            break;

                        case SurvivorAction.PutDown:
                            PutDownAction();
                            break;

                        case SurvivorAction.Inventory:
                            _gameConsoleView.DisplayInventory();
                            break;

                        case SurvivorAction.TalkTo:
                            TalkToAction();
                            break;

                        case SurvivorAction.ListOfIslands:
                            _gameConsoleView.DisplayListOfIslandLocations();
                            break;

                        case SurvivorAction.SurvivorIslandsVisited:
                            _gameConsoleView.DisplayLocationsVisited();
                            break;

                        case SurvivorAction.ListNonplayerCharacters:
                            _gameConsoleView.DisplayListOfAllNpcObjects();
                            break;

                        case SurvivorAction.Travel:
                            //
                            // get new location choice and update the current location property
                            //                        
                            _gameTraveler.lastname = _gameConsoleView.DisplayGetNextIslandLocation();
                            _currentLocation = _gameUniverse.GetIslandLocationById(_gameTraveler.lastname);
                            _gameTraveler.IslandLocationID = _currentLocation.IslandLocationID;
                            //
                            // set the game play screen to the current location info format
                            //
                            _gameConsoleView.DisplayGamePlayScreen("Current Location", Text.CurrentLocationInfo(_currentLocation), ActionMenu.MainMenu, "");
                            break;

                        case SurvivorAction.SecondaryMenu:
                            ActionMenu.currentMenu = ActionMenu.CurrentMenu.SecondaryMenu;
                            _gameConsoleView.DisplayGamePlayScreen("Secondary Menu", "Select an operation from the menu.", ActionMenu.SecondaryMenu, "");
                            break;

                        case SurvivorAction.ReturnToMainMenu:
                            ActionMenu.currentMenu = ActionMenu.CurrentMenu.MainMenu;
                            _gameConsoleView.DisplayGamePlayScreen("Current Location", Text.CurrentLocationInfo(_currentLocation), ActionMenu.MainMenu, "");
                            break;

                        default:
                            break;
                    }
                }

                //
                // close the application
                //
                Environment.Exit(1);
            }
        }

        private void LookAtAction()
        {
            //
            // display a list of game objects in island location and get a player choice
            //
            int gameObjectToLookAtId = _gameConsoleView.DisplayGetGameObjectToLookAt();

            //
            // display game object info
            //
            if (gameObjectToLookAtId != 0)
            {
                //
                // get the game object from the universe
                //
                GameObject gameObject = _gameUniverse.GetGameObjectById(gameObjectToLookAtId);

                //
                // display information for the object chosen
                //
                _gameConsoleView.DisplayGameObjectInfo(gameObject);
            }
        }

        private void PickUpAction()
        {
            //
            // display a list of traveler objects in island location and get a player choice
            //
            int travelerObjectToPickUpId = _gameConsoleView.DisplayGetTravelerObjectToPickUp();

            //
            // add the traveler object to traveler's inventory
            //
            if (travelerObjectToPickUpId != 0)
            {
                //
                // get the game object from the universe
                //
                TravelerObject travelerObject = _gameUniverse.GetGameObjectById(travelerObjectToPickUpId) as TravelerObject;

                //
                // note: traveler object is added to list and the island location is set to 0
                //
                _gameTraveler.Inventory.Add(travelerObject);
                travelerObject.IslandLocationId = 0;

                //
                // display confirmation message
                //
                _gameConsoleView.DisplayConfirmTravelerObjectAddedToInventory(travelerObject);
            }
        }

        private void PutDownAction()
        {
            //
            // display a list of traveler objects in inventory and get a player choice
            //
            int inventoryObjectToPutDownId = _gameConsoleView.DisplayGetInventoryObjectToPutDown();

            //
            // get the game object from the universe
            //
            TravelerObject travelerObject = _gameUniverse.GetGameObjectById(inventoryObjectToPutDownId) as TravelerObject;

            //
            // remove the object from inventory and set the island location to the current value
            //
            _gameTraveler.Inventory.Remove(travelerObject);
            travelerObject.IslandLocationId = _gameTraveler.IslandLocationID;

            //
            // display confirmation message
            //
            _gameConsoleView.DisplayConfirmTravelerObjectRemovedFromInventory(travelerObject);

        }

        /// <summary>
        /// process the Talk To action
        /// </summary>
        private void TalkToAction()
        {
            //
            // display a list of NPCs in space-time location and get a player choice
            //
            int npcToTalkToId = _gameConsoleView.DisplayGetNpcToTalkTo();

            //
            // display NPC's message
            //
            if (npcToTalkToId != 0)
            {
                //
                // get the NPC from the universe
                //
                Npc npc = _gameUniverse.GetNpcById(npcToTalkToId);

                //
                // display information for the object chosen
                //
                _gameConsoleView.DisplayTalkTo(npc);
            }
        }

        /// <summary>
        /// initialize the player info
        /// </summary>
        private void InitializeMission()
        {
            Survivor traveler = _gameConsoleView.GetInitialTravelerInfo();

            _gameTraveler.firstName = traveler.firstName;
            _gameTraveler.lastName = traveler.lastName;
            _gameTraveler.Age = traveler.Age;
            _gameTraveler.preferredSkill = traveler.preferredSkill;
            _gameTraveler.lastname = 1;
            _gameTraveler.HomeTown = traveler.HomeTown;
            _gameTraveler.IslandLocationID = 1;

            _gameTraveler.Health = 0;
            _gameTraveler.Health = 100;
            _gameTraveler.Lives = 1;
        }


        private void UpdateGameStatus()
        {
            if (!_gameTraveler.HasVisited(_currentLocation.IslandLocationID))
            {
                //
                // add new location to the list of visited locations if this is a first visit
                //
                _gameTraveler.IslandLocationsVisited.Add(_currentLocation.IslandLocationID);

                //
                // update experience points for visiting locations
                //
                _gameTraveler.Health += _currentLocation.Health;
            }

            foreach (var theObject in _gameTraveler.Inventory)
            {
                if (theObject.Id == 2)
                {
                    _gameUniverse.GetIslandLocationById(9).Accessable = true;
                    break;
                }
            }

            foreach (var theObject in _gameTraveler.Inventory)
            {
                if (theObject.Id == 1)
                {
                    _gameUniverse.GetIslandLocationById(7).Accessable = true;
                    break;
                }
            }
        }
        #endregion
    }
}
