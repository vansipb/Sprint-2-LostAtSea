﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LostAtSea
{
    /// <summary>
    /// class to store static and to generate dynamic text for the message and input boxes
    /// </summary>
    public static class Text
    {
        public static List<string> HeaderText = new List<string>() { "Lost At Sea" };
        public static List<string> FooterText = new List<string>() { "Stranded Corperation, 2020" };

        #region INTITIAL GAME SETUP

        public static string MissionIntro()
        {
            string messageBoxText =
            "You are a survivalist expert who was traveling from California to Japan in a private jet over " +
            "the Pacific Ocean, when all the sudden you find your plane hurrling throught the sky and crashing " +
            "down into the water. You were sadly the only one who ended up surviving the crash. You then see a " +
            "life jacket floating in the water nearby where you crashed, you then decide to swim towards an island. " +
            "Your missionis to escape the chain of islands and find a way back to civilization. \n" +
            " \n" +
            "\tYour on your own now good luck!\n" +
            " \n" +
            "\tHint: Your first task should be to look around for useful resources\n" +
            " \n" +
            "\tBefore attempting to escape the islands we need to know some information about you press any key to continue.\n" +
            " \n" +
            "\tPress the ESC key at any time during the game to exit. \n";
            return messageBoxText;
        }

        public static string CurrrentLocationInfo()
        {
            string messageBoxText =
            "You are are now on the starting island and are beginning your journey " +
            "through the chain of islands in the Pacific Ocean. " +
            "You will need to travel to other islands in order to survive. " +
            "Wishing you luck on your journey to escape the islands.\n" +
            " \n" +
            "\tChoose from the menu options to proceed.\n";

            return messageBoxText;
        }

        #region Initialize Mission Text

        public static string InitializeMissionIntro()
        {
            string messageBoxText =
                " Before attempting to escape the chain of islands we need to know some inforamtion about you\n" +
                " \n" +
                " ...Just incase anything happens to you\n" +
                " \n" +
                " Please enter the information below\n" +
                " \n" +
                "\tPress any key to begin.";

            return messageBoxText;
        }

        public static string InitializeMissionGetTravelerFirstName()
        {
            string messageBoxText =
                "Enter your firstname Survivor.\n" +
                " \n" +
                "Please use the name you wish to be referred during your mission.";

            return messageBoxText;
        }

        public static string InitializeMissionGetTravelerLastName()
        {
            string messageBoxText =
                "Enter your lastname Survivor.\n" +
                " \n";

            return messageBoxText;
        }

        public static string InitializeMissionGetTravelerAge(Survivor gameTraveler)
        {
            string messageBoxText =
                $"Very good then, we will call you {gameTraveler.firstName} on this survival mission.\n" +
                " \n" +
                "Enter your age below.\n" +
                " \n" +
                "Please use the standard Earth year as your reference.";

            return messageBoxText;
        }

        public static string InitializeMissionGetTravelerHomeTown()
        {
            string messageBoxText =
                "Enter your hometown location below Survivor.\n" +
                " \n";

            return messageBoxText;
        }

        public static string InitializeMissionGetTravelerPreferredSkill(Survivor gameTraveler)
        {
            string messageBoxText =
                $"{gameTraveler.firstName}, it will be important for us to know your preferred skill on this mission.\n" +
                " \n" +
                "Enter your preferred skill below.\n" +
                " \n" +
                "Please chose a skill listed below." +
                " \n";

            string preferredSkillList = null;

            foreach (Character.preferredSkillType preferredSkill in Enum.GetValues(typeof(Character.preferredSkillType)))
            {
                if (preferredSkill != Character.preferredSkillType.None)
                {
                    preferredSkillList += $"\t{preferredSkill}\n";
                }
            }

            messageBoxText += preferredSkillList;

            return messageBoxText;
        }



        public static string InitializeMissionEchoTravelerInfo(Survivor gameTraveler)
        {
            string messageBoxText =
                $"Very good then {gameTraveler.firstName}.\n" +
                " \n" +
                "Here is all the required data incase anything happens to you, You will find it" +
                " listed below.\n" +
                " \n" +
                $"\tSurvivor firstname: {gameTraveler.firstName}\n" +
                $"\tSurvivor lastname: {gameTraveler.lastName}\n" +
                $"\tSurvivor Age: {gameTraveler.Age}\n" +
                $"\tSurvivor Preferred Skill: {gameTraveler.preferredSkill}\n" +
                $"\tSurvivor Hometown: {gameTraveler.HomeTown}\n" +
                " \n" +
                "Press any key to begin your mission.";

            return messageBoxText;
        }


        #endregion

        #endregion

        #region MAIN MENU ACTION SCREENS

        public static string TravelerInfo(Survivor gameTraveler)
        {
            string messageBoxText =
                $"\tSurvivor firstname: {gameTraveler.firstName}\n" +
                $"\tSurvivor lastname: {gameTraveler.lastName}\n" +
                $"\tSurvivor age: {gameTraveler.Age}\n" +
                $"\tSurvivor preferred skill: {gameTraveler.preferredSkill}\n" +
                $"\tSurvivor hometown: {gameTraveler.HomeTown}\n" +
                " \n";

            return messageBoxText;
        }

        public static string CurrentLocationInfo(IslandLocation islandLocation)
        {
            string messageBoxText =
                $"Current Location: {islandLocation.CommonName}\n" +
                " \n" +
                islandLocation.Description;

            return messageBoxText;
        }


        public static string TravelerInv(Survivor gameTraveler)
        {
            string messageBoxText =
                $"\tSurvivor firstName: {gameTraveler.firstName}\n";

            return messageBoxText;
        }

        public static string LookAround(IslandLocation islandLocation)
        {
            string messageBoxText =
                $"Current Location: {islandLocation.CommonName}\n" +
                " \n" +
                islandLocation.GeneralContents;

            return messageBoxText;
        }

        public static string ListAllGameObjects(IEnumerable<GameObject> gameObjects)
        {
            //
            // display table name and column headers
            //
            string messageBoxText =
                "Game Objects\n" +
                " \n" +

                //
                // display table header
                //
                "ID".PadRight(10) +
                "Name".PadRight(30) +
                "Island Location Id".PadRight(10) + "\n" +
                "____".PadRight(10) +
                "______________________".PadRight(30) +
                "______________________".PadRight(10) + "\n";

            //
            // display all traveler objects in rows
            //
            string gameObjectRows = null;
            foreach (GameObject gameObject in gameObjects)
            {
                gameObjectRows +=
                    $"{gameObject.Id}".PadRight(10) +
                    $"{gameObject.Name}".PadRight(30) +
                    $"{gameObject.IslandLocationId}".PadRight(10) +
                    Environment.NewLine;
            }

            messageBoxText += gameObjectRows;

            return messageBoxText;
        }

        public static string ListIslandTimeLocationObjectsByIslandTimeLocation(int islandLocationId, IEnumerable<GameObject> gameObjects)
        {
            //
            // generate a list of traveler objects from the game object list with the current island location id
            //
            List<IslandLocationObject> islandLocationObjects = new List<IslandLocationObject>();
            foreach (var gameObject in gameObjects)
            {
                if (gameObject is TravelerObject &&
                    gameObject.IslandLocationId == islandLocationId)
                {
                    islandLocationObjects.Add(gameObject as IslandLocationObject);
                }
            }

            //
            // display table name and column headers
            //
            string messageBoxText =
                "Island Location Objects\n" +
                " \n" +

                //
                // display table header
                //
                "ID".PadRight(10) + "Name".PadRight(30) + "\n" +
                "____".PadRight(10) + "_____________________".PadRight(30) +
                "_____________________".PadRight(20) + "\n";

            //
            // display all traveler objects in rows
            //
            string islandLocationObjectRows = null;
            foreach (IslandLocationObject islandTimeLocationObject in islandLocationObjects)
            {
                islandLocationObjectRows +=
                    $"{islandTimeLocationObject.Id}".PadRight(10) +
                    $"{islandTimeLocationObject.Name}".PadRight(30) +
                    Environment.NewLine;
            }

            messageBoxText += islandLocationObjectRows;

            return messageBoxText;
        }

        public static string ListAllNpcObjects(IEnumerable<Npc> npcObjects)
        {
            //
            // display table name and column headers
            //
            string messageBoxText =
                "NPC Objects\n" +
                " \n" +

                //
                // display table header
                //
                "ID".PadRight(10) +
                "Name".PadRight(30) +
                "Island Location Id".PadRight(10) + "\n" +
                "___".PadRight(10) +
                "______________________".PadRight(30) +
                "______________________".PadRight(10) + "\n";

            //
            // display all npc objects in rows
            //
            string npcObjectRows = null;
            foreach (Npc npcObject in npcObjects)
            {
                npcObjectRows +=
                    $"{npcObject.Id}".PadRight(10) +
                    $"{npcObject.firstName}".PadRight(30) +
                    $"{npcObject.IslandLocationID}".PadRight(10) +
                    Environment.NewLine;
            }

            messageBoxText += npcObjectRows;

            return messageBoxText;
        }

        public static string GameObjectsChooseList(IEnumerable<GameObject> gameObjects)
        {
            //
            // display table name and column headers
            //
            string messageBoxText =
                "Game Objects\n" +
                " \n" +

                //
                // display table header
                //
                "ID".PadRight(10) +
                "Name".PadRight(30) + "\n" +
                "____".PadRight(10) +
                "______________________".PadRight(30) + "\n";

            //
            // display all traveler objects in rows
            //
            string gameObjectRows = null;
            foreach (GameObject gameObject in gameObjects)
            {
                gameObjectRows +=
                    $"{gameObject.Id}".PadRight(10) +
                    $"{gameObject.Name}".PadRight(30) +
                    Environment.NewLine;
            }

            messageBoxText += gameObjectRows;

            return messageBoxText;
        }

        public static string Travel(Survivor gametraveler, List<IslandLocation> islandLocations)
        {
            string messageBoxText =
                $"{gametraveler.firstName}, We will need to know the next location you plan on traveling to.\n" +
                " \n" +
                "Enter the ID number of your desired location from the table below.\n" +
                " \n" +

                //
                // display table header
                //
                "ID".PadRight(10) + "Name".PadRight(30) + "Accessible".PadRight(10) + "\n" +
                "____".PadRight(10) + "______________________".PadRight(30) + "_________".PadRight(10) + "\n";

            //
            // display all locations except the current location
            //
            string islandLocationList = null;
            foreach (IslandLocation islandLocation in islandLocations)
            {
                if (islandLocation.IslandLocationID != gametraveler.lastname)
                {
                    islandLocationList +=
                        $"{islandLocation.IslandLocationID}".PadRight(10) +
                        $"{islandLocation.CommonName}".PadRight(30) +
                        $"{islandLocation.Accessable}".PadRight(10) +
                        Environment.NewLine;
                }
            }

            messageBoxText += islandLocationList;

            return messageBoxText;
        }

        public static string VisitedLocations(IEnumerable<IslandLocation> islandLocations)
        {
            string messageBoxText =
                "Islands Locations Visited\n" +
                " \n" +

                //
                // display table header
                //
                "ID".PadRight(10) + "Name".PadRight(30) + "\n" +
                "____".PadRight(10) + "________________________".PadRight(30) + "\n";

            //
            // display all locations
            //
            string islandLocationList = null;
            foreach (IslandLocation islandLocation in islandLocations)
            {
                islandLocationList +=
                    $"{islandLocation.IslandLocationID}".PadRight(10) +
                    $"{islandLocation.CommonName}".PadRight(30) +
                    Environment.NewLine;
            }

            messageBoxText += islandLocationList;

            return messageBoxText;
        }

        public static string LookAt(GameObject gameObject)
        {
            string messageBoxText = "";

            messageBoxText =
                $"{gameObject.Name}\n" +
                " \n" +
                gameObject.Description + " \n" +
                " \n";

            if (gameObject is TravelerObject)
            {
                TravelerObject travelerObject = gameObject as TravelerObject;

                messageBoxText += $"The {travelerObject.Name} can ";

                if (travelerObject.CanInventory)
                {
                    messageBoxText += "be added to your inventory.";
                }
                else
                {
                    messageBoxText += "not be added to your inventory.";
                }
            }
            else
            {
                messageBoxText += $"The {gameObject.Name} may not be added to your inventory.";
            }

            return messageBoxText;
        }

        public static string CurrentInventory(IEnumerable<TravelerObject> inventory)
        {
            string messageBoxText = "";

            messageBoxText =
            "ID".PadRight(10) +
            "Name".PadRight(30) +
            "\n" +
            "___".PadRight(10) +
            "__________________________".PadRight(30) +
            "\n";

            string inventoryObjectRows = null;
            foreach (TravelerObject inventoryObject in inventory)
            {
                inventoryObjectRows +=
                    $"{inventoryObject.Id}".PadRight(10) +
                    $"{inventoryObject.Name}".PadRight(30) +
                    Environment.NewLine;
            }

            messageBoxText += inventoryObjectRows;

            return messageBoxText;
        }

        public static string ListAllIslandLocations(IEnumerable<IslandLocation> islandLocations)
        {
            string messageBoxText =
                "Islands\n" +
                " \n" +

                //
                // display table header
                //
                "ID".PadRight(10) + "Name".PadRight(30) + "\n" +
                "___".PadRight(10) + "_______________________".PadRight(30) + "\n";

            //
            // display all locations
            //
            string islandLocationList = null;
            foreach (IslandLocation islandLocation in islandLocations)
            {
                islandLocationList +=
                    $"{islandLocation.IslandLocationID}".PadRight(10) +
                    $"{islandLocation.CommonName}".PadRight(30) +
                    Environment.NewLine;
            }

            messageBoxText += islandLocationList;

            return messageBoxText;
        }

        public static string NpcsChooseList(IEnumerable<Npc> npcs)
        {
            //
            // display table name and column headers
            //
            string messageBoxText =
                "NPCs\n" +
                " \n" +

                //
                // display table header
                //
                "ID".PadRight(10) +
                "Name".PadRight(30) + "\n" +
                "___".PadRight(10) +
                "______________________".PadRight(30) + "\n";

            //
            // display all NPCs in rows
            //
            string npcRows = null;
            foreach (Npc npc in npcs)
            {
                npcRows +=
                    $"{npc.Id}".PadRight(10) +
                    $"{npc.firstName}".PadRight(30) +
                    Environment.NewLine;
            }

            messageBoxText += npcRows;

            return messageBoxText;
        }

        public static List<string> StatusBox(Survivor traveler, Universe universe)
        {
            List<string> statusBoxText = new List<string>();

            statusBoxText.Add($"Health: {traveler.Health} | Lives: {traveler.Lives}\n");

            return statusBoxText;
        }
        #endregion
    }
}
