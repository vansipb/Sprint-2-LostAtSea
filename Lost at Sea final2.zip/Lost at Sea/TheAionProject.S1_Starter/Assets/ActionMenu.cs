﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LostAtSea
{
    /// <summary>
    /// static class to hold key/value pairs for menu options
    /// </summary>
   public static class ActionMenu
    {
        public enum CurrentMenu
        {
            MissionIntro,
            InitializeMission,
            MainMenu,
            SecondaryMenu
        }

        public static CurrentMenu currentMenu = CurrentMenu.MainMenu;
        public static Menu MissionIntro = new Menu()
        {
            MenuName = "MissionIntro",
            MenuTitle = "",
            MenuChoices = new Dictionary<char, SurvivorAction>()
                    {
                        { ' ', SurvivorAction.None }
                    }
        };

        public static Menu InitializeMission = new Menu()
        {
            MenuName = "InitializeMission",
            MenuTitle = "Initialize Mission",
            MenuChoices = new Dictionary<char, SurvivorAction>()
                {
                    { '1', SurvivorAction.Exit }
                }
        };

        public static Menu MainMenu = new Menu()
        {
            MenuName = "MainMenu",
            MenuTitle = "Main Menu",
            MenuChoices = new Dictionary<char, SurvivorAction>()
                {
                    { '1', SurvivorAction.SurvivorInfo },
                    { '2', SurvivorAction.LookAround },
                    { '3', SurvivorAction.TalkTo },
                    { '4', SurvivorAction.LookAt },
                    { '5', SurvivorAction.PickUp },
                    { '6', SurvivorAction.PutDown },
                    { '7', SurvivorAction.Inventory },
                    { '8', SurvivorAction.Travel },
                    { '9', SurvivorAction.SecondaryMenu },
                    { '0', SurvivorAction.Exit }
                }
           };


        public static Menu SecondaryMenu = new Menu()
        {
            MenuName = "Secondary Menu",
            MenuTitle = "Secondary Menu",
            MenuChoices = new Dictionary<char, SurvivorAction>()
                {
                    { '1', SurvivorAction.ListOfIslands },
                    { '2', SurvivorAction.SurvivorIslandsVisited },
                    { '3', SurvivorAction.ListSurvivorObjects },
                    { '4', SurvivorAction.ListNonplayerCharacters},
                    { '0', SurvivorAction.ReturnToMainMenu }
                }
        };
    }
}
