﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheAionProject
{
    /// <summary>
    /// static class to hold all objects in the game universe; locations, game objects, npc's
    /// </summary>
    public static partial class UniverseObjects
    {
        public static List<GameObject> gameObjects = new List<GameObject>()
        {
            new TravelerObject
            {
                Id = 1,
                Name = "FlashLight",
                SpaceTimeLocationId = 2,
                Description = "A item used to look around in caves and help find items in the dark.",
                Type = TravelerObjectType.Treasure,
                Value = 45,
                CanInventory = true,
                IsVisible = true
            },

            new TravelerObject
            {
                Id = 2,
                Name = "Wood, String, Supplies to build a raft",
                SpaceTimeLocationId = 3,
                Description = "Wood, string, and supplies to build a raft all you have to do now is build it!",
                Type = TravelerObjectType.Treasure,
                Value = 45,
                CanInventory = true,
                IsVisible = true
            },

            new TravelerObject
            {
                Id = 3,
                Name = "Food",
                SpaceTimeLocationId = 3,
                Description = "Fresh potatoes, wheat, and many other island food tiems.",
                Type = TravelerObjectType.Medicine,
                Value = 45,
                CanInventory = false,
                IsConsumable = true,
                IsVisible = true
            },

            new TravelerObject
            {
                Id = 4,
                Name = "Coconuts (fresh water)",
                IslandLocationID = 3,
                Description =
                    "Fresh Coconuts that can be broken open to have consumable drinking water.",
                Type = TravelerObjectType.Information,
                Value = 0,
                CanInventory = true,
                IsVisible = true
            },

            new TravelerObject
            {
                Id = 8,
                Name = "lighter",
                IslandLocationID = 0,
                Description =
                    "Used to help light fires.",
                Type = TravelerObjectType.Information,
                Value = 0,
                CanInventory = true,
                IsVisible = true
            },

            new TravelerObject
            {
                Id = 9,
                Name = "Boat Motor",
                IslandLocationID = 9,
                Description =
                    "A boat motor that is easy able to attach to your raft and has enough gas to get you to safty.",
                Type = TravelerObjectType.Food,
                Value = 0,
                CanInventory = true,
                IsVisible = true
            },
        };    
    }
}
