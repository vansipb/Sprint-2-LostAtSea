﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LostAtSea
{
    /// <summary>
    /// static class to hold all npc objects
    /// </summary>
    public static partial class UniverseObjects
    {
        public static List<Npc> Npcs = new List<Npc>()
        {
            new Civilian
            {
                Id = 1,
                firstName = "Dying Man",
                IslandLocationID = 1,
                Description = "A man that barely survived the plane crash along with you",
                Messages = new List<string>
                {
                    "Please tell them I love them",
                    "You need to escape these islands, it's going to take everything you got",
                    "I need you to do me a favor, please find my family "
                }
            },

            new Civilian
            {
                Id = 2,
                firstName = "Lone Survivor",
                IslandLocationID = 8,
                Description = "A man whos been here for a long time",
                Messages = new List<string>
                {
                    "Your not gunna make it!",
                    "Your not gunna escape this plce unless you got a raft.",
                    "I've been stuck here for 3 years."
                }
            },

            new Civilian
            {
                Id = 3,
                firstName = "Lone Survivor",
                IslandLocationID = 4,
                Description = "A man whos been here for a long time",
                Messages = new List<string>
                {
                    "This might sound crazy but if you see a shark don't talk to him!!!!!!!!!!!",
                    "I need to go right now!",
                    "Where are we? I've been here for so long."
                }
            },

            new Civilian
            {
                Id = 4,
                firstName = "Shark",
                IslandLocationID = 9,
                Description = "Are you sure you want to talk to him?",
                Messages = new List<string>
                {
                    "You got eaten... Press {0} to exit game" 
                }
            }

        };
    }
}
