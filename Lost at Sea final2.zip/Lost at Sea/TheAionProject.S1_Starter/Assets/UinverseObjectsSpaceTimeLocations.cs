﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LostAtSea
{
    /// <summary>
    /// static class to hold all objects in the game universe; locations, game objects, npc's
    /// </summary>
    public static partial class UniverseObjects
    {
        public static List<IslandLocation> IslandLocations = new List<IslandLocation>()
        {

            new IslandLocation
            {
                CommonName = "Starting Island",
                IslandLocationID = 1,
                UniversalLocation = "Starting Island",
                Description = "This is the island you find yourself on after the crash." ,
                GeneralContents = "A whole lot of palm trees" ,
                Accessable = true,
            },

            new IslandLocation
            {
                CommonName = "Island A",
                IslandLocationID = 2,
                UniversalLocation = "I-1",
                Description = "One of the available islands to travel to, look around and see what you can find." ,
                GeneralContents = "- Flashlight-",
                Accessable = true,
                Health = -10,
            },

            new IslandLocation
            {
                CommonName = "Island B",
                IslandLocationID = 3,
                UniversalLocation = "I-2",
                Description = "One of the available islands to travel to, look around and see what you can find. " ,
                GeneralContents = "- Wood, string, supplies to build a raft -",
                Accessable = true,
                Health = -10,
            },

            new IslandLocation
            {
                CommonName = "Island C",
                IslandLocationID = 4,
                UniversalLocation = "I-3",
                Description = "One of the available islands to travel to, look around and see what you can find. " ,
                GeneralContents = "- Food -",
                Accessable = true,
                Health = 50,
            },


            new IslandLocation
            {
                CommonName = "Island D",
                IslandLocationID = 5,
                UniversalLocation = "I-4",
                Description = "One of the available islands to travel to, look around and see what you can find. " ,
                GeneralContents = "- Coconuts (fresh water) -",
                Accessable = true,
                Health = 50,
            },

            new IslandLocation
            {
                CommonName = "Island E",
                IslandLocationID = 6,
                UniversalLocation = "I-5",
                Description = "One of the available islands to travel to, look around and see what you can find. " ,
                GeneralContents = "- Cave -",
                Accessable = true,
                Health = -10,
            },

            new IslandLocation
            {
                CommonName = "Island E Cave",
                IslandLocationID = 7,
                UniversalLocation = "Cave on island 5",
                Description = "If you don't have a flashlight, you struggle to find your way out" ,
                GeneralContents = "-Nothing-",
                Accessable = false,
                Health = -40,
            },

            new IslandLocation
            {
                CommonName = "Island E Cave",
                IslandLocationID = 7,
                UniversalLocation = "Cave on island 5",
                Description = "You manage to explore the cave with no troubles because of your flash light, look around and see what you can find" ,
                GeneralContents = "-Lighter-",
                Accessable = false,
                Health = -10,
            },

            new IslandLocation
            {
                CommonName = "Island F",
                IslandLocationID = 8,
                UniversalLocation = "I-6",
                Description = "One of the available islands to travel to, look around and see what you can find. " ,
                GeneralContents = "-NPC-",
                Accessable = true,
                Health = -10,
            },

            new IslandLocation
            {
                CommonName = "Escape Island",
                IslandLocationID = 9,
                UniversalLocation = "I-7",
                Description = "Look around and see what there is, Congratulations you have successfully survived and escaped!!! Press {0} To Exit",
                GeneralContents = "-Boat Motor-",
                Accessable = false,
            },
        };
    }
}
