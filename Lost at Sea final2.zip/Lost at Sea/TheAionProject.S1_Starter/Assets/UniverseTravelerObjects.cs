﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LostAtSea
{
    /// <summary>
    /// static class to hold all objects in the game universe; locations, game objects, npc's
    /// </summary>
    public static partial class UniverseObjects
    {
        public static List<GameObject> gameObjects = new List<GameObject>()
        {
            new TravelerObject
            {
                Id = 1,
                Name = "FlashLight",
                IslandLocationId = 2,
                Description = "A item used to look around in caves and help find things in the dark.",
                CanInventory = true,
                IsValue = true,
                IsVisible = true
            },

            new TravelerObject
            {
                Id = 2,
                Name = "Wood, String, cloth",
                IslandLocationId = 3,
                Description = "Wood, string, and supplies to build a raft all you have to do now is build it!",
                CanInventory = true,
                IsValue = true,
                IsVisible = true
            },

            new TravelerObject
            {
                Id = 9,
                Name = "Food",
                IslandLocationId = 4,
                Description = "Fresh potatoes, wheat, and many other island food tiems.",
                CanInventory = true,
                IsValue = true,
                IsVisible = true
            },

            new TravelerObject
            {
                Id = 7,
                Name = "Coconuts (fresh water)",
                IslandLocationId = 5,
                Description = "Fresh Coconuts that can be broken open to have consumable drinking water.",
                CanInventory = true,
                IsValue = true,
                IsVisible = true
            },

            new TravelerObject
            {
                Id = 6,
                Name = "lighter",
                IslandLocationId = 7,
                Description = "Used to help light fires.",
                CanInventory = true,
                IsValue = true,
                IsVisible = true
            },

           new TravelerObject
            {
                Id = 8,
                Name = "backpack",
                IslandLocationId = 0,
                Description = "Storage for extra items you may find",
                CanInventory = true,
                IsValue = true,
                IsVisible = true
            },

            new TravelerObject
            {
                Id = 5,
                Name = "Boat Motor",
                IslandLocationId = 9,
                Description = "A boat motor that is easy able to attach to your raft and has enough gas to get you to safty.",
                CanInventory = true,
                IsValue = true,
                IsVisible = true
            },
        };
    }
}