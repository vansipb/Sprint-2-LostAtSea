﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Media;

namespace LostAtSea
{
    class Program
    {


        /// <summary>
        /// instantiate the game controller, passing all control to the new Controller object
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Controller gameController = new Controller();
            PlayMusic();          
            Console.ReadKey();
        }

        static void PlayMusic()
        {
        SoundPlayer OceanSound = new SoundPlayer("OceanSound.wav");

            OceanSound.PlaySync();
        }
    }
}
