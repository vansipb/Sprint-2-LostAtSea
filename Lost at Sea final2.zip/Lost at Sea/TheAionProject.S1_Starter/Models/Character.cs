﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LostAtSea
{
    /// <summary>
    /// base class for the player and all game characters
    /// </summary>
    public class Character
    {
        #region ENUMERABLES

        public enum preferredSkillType
        {
            None,
            Hunting =1,
            Fishing =2 ,
            Building =3
        }

        #endregion

        #region FIELDS

        private string _firstname;
        private int _lastname;
        private int _age;
        private preferredSkillType preferredskill;
        private int homeTown;
        private int spaceTimeLocationID;


        #endregion

        #region PROPERTIES  

        public int IslandLocationID
        {
            get { return spaceTimeLocationID; }
            set { spaceTimeLocationID = value; }
        }


        public string firstName
        {
            get { return _firstname; }
            set { _firstname = value; }
        }

        public int lastname
        {
            get { return _lastname; }
            set { _lastname = value; }
        }

        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }

        public preferredSkillType preferredSkill
        {
            get { return preferredskill; }
            set { preferredskill = value; }
        }

        public int hometown
        {
            get { return homeTown; }
            set { homeTown = value; }
        }


        #endregion

        #region CONSTRUCTORS

        public Character()
        {

        }

        public Character(string firstname, preferredSkillType preferredSkill, int lastname, int homeTown)
        {
            _firstname = firstname;
            preferredskill = preferredSkill;
            _lastname = lastname;
            homeTown = hometown;
        }

        public Character(string firstname, preferredSkillType preferredSkill, int lastname, int homeTown, int spaceTimeLocationID) : this(firstname, preferredSkill, lastname, homeTown)
        {
            this.spaceTimeLocationID = spaceTimeLocationID;
        }

        #endregion

        #region METHODS



        #endregion
    }
}
