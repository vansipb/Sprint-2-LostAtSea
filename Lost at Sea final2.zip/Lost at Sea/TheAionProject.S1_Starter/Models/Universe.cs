﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LostAtSea
{
    /// <summary>
    /// class of the game map
    /// </summary>
    public class Universe
    {

        //
        // list of all island locations and game objects
        //
        private List<GameObject> _gameObjects;
        private List<IslandLocation> _islandLocations;
        private List<Npc> _npcs;

        public List<GameObject> GameObjects
        {
            get { return _gameObjects; }
            set { _gameObjects = value; }
        }

        public List<IslandLocation> IslandLocations
        {
            get { return _islandLocations; }
            set { _islandLocations = value; }
        }

        public List<Npc> Npcs
        {
            get { return _npcs; }
            set { _npcs = value; }
        }

        #region ***** define all lists to be maintained by the Universe object *****

        #endregion

        #region ***** constructor *****

        //
        // default Universe constructor
        //
        public Universe()
        {
            //
            // add all of the universe objects to the game
            // 
            IntializeUniverse();
        }

        #endregion

        /// <summary>
        /// initialize the universe with all of the island locations and game objects
        /// </summary>
        private void IntializeUniverse()
        {
            _islandLocations = UniverseObjects.IslandLocations;
            _gameObjects = UniverseObjects.gameObjects;
            _npcs = UniverseObjects.Npcs;
        }

        #region ***** define methods to initialize all game elements *****

        /// <summary>
        /// initialize the universe with all of the island locations
        /// </summary>

        #endregion

        #region ***** define methods to return game element objects and information *****

        public bool IsValidIslandLocationId(int islandLocationId)
        {
            List<int> islandLocationIds = new List<int>();

            //
            // create a list of island location ids
            //
            foreach (IslandLocation stl in _islandLocations)
            {
                islandLocationIds.Add(stl.IslandLocationID);
            }

            //
            // determine if the island location id is a valid id and return the result
            //
            if (islandLocationIds.Contains(islandLocationId))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool IsValidGameObjectByLocationId(int gameObjectId, int currentIslandLocation)
        {
            List<int> gameObjectIds = new List<int>();

            //
            // create a list of traveler object ids in current island location
            //
            foreach (GameObject gameObject in _gameObjects)
            {
                if (gameObject.IslandLocationId == currentIslandLocation)
                {
                    gameObjectIds.Add(gameObject.Id);
                }

            }

            //
            // determine if the game object id is a valid id and return the result
            //
            if (gameObjectIds.Contains(gameObjectId))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool IsValidTravelerObjectByLocationId(int gameObjectId, int currentIslandLocation)
        {
            List<int> travelerObjectIds = new List<int>();

            //
            // create a list of game object ids in current island location
            //
            foreach (GameObject gameObject in _gameObjects)
            {
                if (gameObject.IslandLocationId == currentIslandLocation && gameObject is TravelerObject)
                {
                    travelerObjectIds.Add(gameObject.Id);
                }

            }

            //
            // determine if the game object id is a valid id and return the result
            //
            if (travelerObjectIds.Contains(gameObjectId))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool IsValidNpcByLocationId(int npcId, int currentSpaceTimeLocation)
        {
            List<int> npcIds = new List<int>();

            //
            // create a list of NPC ids in current island location
            //
            foreach (Npc npc in _npcs)
            {
                if (npc.IslandLocationID == currentSpaceTimeLocation)
                {
                    npcIds.Add(npc.Id);
                }

            }

            //
            // determine if the game object id is a valid id and return the result
            //
            if (npcIds.Contains(npcId))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// determine if a location is accessible to the player
        /// </summary>
        /// <param name="islandLocationId"></param>
        /// <returns>accessible</returns>
        public bool IsAccessibleLocation(int islandLocationId)
        {
            IslandLocation islandLocation = GetIslandLocationById(islandLocationId);
            if (islandLocation.Accessable == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// return the current maximum ID for a SpaceTimeLocation object
        /// </summary>
        /// <returns>max SpaceTimeLocationObjectID </returns>
        public int GetMaxIslandLocationId()
        {
            int MaxId = 0;

            foreach (IslandLocation islandLocation in _islandLocations)
            {
                if (islandLocation.IslandLocationID > MaxId)
                {
                    MaxId = islandLocation.IslandLocationID;
                }
            }
            return MaxId;
        }

        /// <summary>
        /// get a game object using an Id
        /// </summary>
        /// <param name="Id">game object Id</param>
        /// <returns>requested game object</returns>

        public GameObject GetGameObjectById(int Id)
        {
            GameObject gameObjectToReturn = null;

            //
            // run through the game object list and grab the correct one
            //
            foreach (GameObject gameObject in _gameObjects)
            {
                if (gameObject.Id == Id)
                {
                    gameObjectToReturn = gameObject;
                }
            }

            //
            // the specified ID was not found in the universe
            // throw and exception
            //
            if (gameObjectToReturn == null)
            {
                string feedbackMessage = $"The Game Object ID {Id} does not exist in the current Universe.";
                throw new ArgumentException(Id.ToString(), feedbackMessage);
            }

            return gameObjectToReturn;
        }

        /// <summary>
        /// return the maximum ID for a GameObject object
        /// </summary>
        /// <returns>max GameObjectID </returns>
        public int GetMaxGameObjectId()
        {
            int MaxId = 0;

            foreach (GameObject gameObject in _gameObjects)
            {
                if (gameObject.Id > MaxId)
                {
                    MaxId = gameObject.Id;
                }
            }

            return MaxId;
        }

        public List<GameObject> GetGameObjectsByIslandLocationId(int islandLocationId)
        {
            List<GameObject> gameObjects = new List<GameObject>();

            //
            // run through the game object list and grab all that are in the current island location
            //
            foreach (GameObject gameObject in _gameObjects)
            {
                if (gameObject.IslandLocationId == islandLocationId)
                {
                    gameObjects.Add(gameObject);
                }
            }

            return gameObjects;
        }

        /// <summary>
        /// get a IslandLocation object using an Id
        /// </summary>
        /// <param name="Id">island location Id</param>
        /// <returns>requested island location</returns>
        public IslandLocation GetIslandLocationById(int Id)
        {
            IslandLocation islandLocation = null;

            //
            // run through the island location list and grab the correct one
            //
            foreach (IslandLocation location in _islandLocations)
            {
                if (location.IslandLocationID == Id)
                {
                    islandLocation = location;
                }
            }

            //
            // the specified ID was not found in the universe
            // throw and exception
            //
            if (islandLocation == null)
            {
                string feedbackMessage = $"The Island Location ID {Id} does not exist in the chain of islands.";
                throw new ArgumentException(Id.ToString(), feedbackMessage);
            }

            return islandLocation;
        }

        public Npc GetNpcById(int Id)
        {
            Npc npcToReturn = null;

            //
            // run through the NPC object list and grab the correct one
            //
            foreach (Npc npc in _npcs)
            {
                if (npc.Id == Id)
                {
                    npcToReturn = npc;
                }
            }

            //
            // the specified ID was not found in the universe
            // throw and exception
            //
            if (npcToReturn == null)
            {
                string feedbackMessage = $"The NPC ID {Id} does not exist in the current Universe.";
                throw new ArgumentException(Id.ToString(), feedbackMessage);
            }

            return npcToReturn;
        }

        public List<TravelerObject> GetTravelerObjectsByIslandLocationId(int islandLocationId)
        {
            List<TravelerObject> travelerObjects = new List<TravelerObject>();

            //
            // run through the game object list and grab all that are in the current island location
            //
            foreach (GameObject gameObject in _gameObjects)
            {
                if (gameObject.IslandLocationId == islandLocationId && gameObject is TravelerObject)
                {
                    travelerObjects.Add(gameObject as TravelerObject);
                }
            }

            return travelerObjects;
        }

        public List<Npc> GetNpcsBySpaceTimeLocationId(int spaceTimeLocationId)
        {
            List<Npc> npcs = new List<Npc>();

            //
            // run through the NPC object list and grab all that are in the current island location
            //
            foreach (Npc npc in _npcs)
            {
                if (npc.IslandLocationID == spaceTimeLocationId)
                {
                    npcs.Add(npc);
                }
            }

            return npcs;
        }

        #endregion
    }
}
