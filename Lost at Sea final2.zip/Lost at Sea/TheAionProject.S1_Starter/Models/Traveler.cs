﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LostAtSea
{
    /// <summary>
    /// the character class the player uses in the game
    /// </summary>
    public class Survivor : Character
    {
        #region ENUMERABLES


        #endregion

        #region FIELDS
        private string _lastname;
        private string homeTown;
        private int _health;
        private int _lives;
        private List<int> _islandLocationsVisited;
        private List<TravelerObject> _inventory;


        #endregion


        #region PROPERTIES

        public int Health
        {
            get { return _health; }
            set { _health = value; }
        }

        public int Lives
        {
            get { return _lives; }
            set { _lives = value; }
        }

        public List<int> IslandLocationsVisited
        {
            get { return _islandLocationsVisited; }
            set { _islandLocationsVisited = value; }
        }


        public string lastName
        {
            get { return _lastname; }
            set { _lastname = value; }
        }

        public string HomeTown
        {
            get { return homeTown; }
            set { homeTown = value; }
        }

        public List<TravelerObject> Inventory
        {
            get { return _inventory; }
            set { _inventory = value; }
        }


        #endregion


        #region CONSTRUCTORS

        public Survivor()
        {
            _islandLocationsVisited = new List<int>();
            _inventory = new List<TravelerObject>();
        }

        public Survivor(string firstname, preferredSkillType preferredskill, int lastname, int hometown) : base(firstname, preferredskill, lastname, hometown)
        {
            _islandLocationsVisited = new List<int>();
            _inventory = new List<TravelerObject>();
        }


        #endregion


        #region METHODS

        public bool HasVisited(int _islandLocationID)
        {
            if (IslandLocationsVisited.Contains(_islandLocationID))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        #endregion
    }
}
