﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LostAtSea
{
    /// <summary>
    /// enum of all possible player actions
    /// </summary>
    public enum SurvivorAction
    {
        None,
        SurvivorInfo,
        MissionSetup,
        LookAround,
        LookAt,
        PickUp,
        PutDown,
        Inventory,
        PickUpItem,
        PutDownItem,
        TalkTo,
        Travel,

        SecondaryMenu,
        ListOfIslands,
        ListGameObjects,
        ReturnToMainMenu,
        SurvivorInv,
        SurvivorTreasure,
        ListSurvivorObjects,
        ListTARDISDestinations,
        ListNonplayerCharacters,
        SurvivorIslandsVisited,
        ListItems,
        ListTreasures,
        Exit
    }
}
